# Privacy Policy

This extension does not collect, store, transmit, or share any personal data.

## Data Handling

- **Local Processing**: All video processing is performed locally in the user's browser.
- **No Analytics**: No analytics, tracking, or external network requests are performed by the extension.
- **No Data Collection**: We do not collect any information about your browsing activity, video content, or any other personal data.

## Contact

If you have questions, contact: singhvaibhavip@gmail.com
